# Instructions

The website should run when you open the index.html.
But I didn't test it and the serviceWorker.js wouldn't work (the path refers to the root directory).

So you should run the website on a server (I used Ritwick Dey's "Live Server" extension for VSCode).
The homepage/starting page is the index.html.

Also, darkmode does not work in Safari. I thought about changing my code to the regular way (with classes), but I don't think that's necessary since the site isn't published.
Also, it's not the best idea to use JS to insert the header and footer on an agency website, as there are companies that block JS for security reasons. Therefore, it would be better to use a static website generator like Gatsby or just use PHP for such tasks.

Translated with www.DeepL.com/Translator (free version)